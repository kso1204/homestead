<th class="align-middle border-top-0" style="width: 1%;">
    <input type="checkbox" wire:model="checkboxAll">
</th>
