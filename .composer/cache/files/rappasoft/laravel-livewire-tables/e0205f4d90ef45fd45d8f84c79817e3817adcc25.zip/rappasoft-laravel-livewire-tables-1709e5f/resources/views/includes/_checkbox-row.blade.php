<td class="align-middle" style="width: 1%;">
    <input type="checkbox" wire:model="checkboxValues" value="{{ $model->{$checkboxAttribute} }}">
</td>
