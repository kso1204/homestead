# Changelog

All notable changes to `lockout` will be documented in this file

## [Unreleased]

## [1.0.1] - 2020-06-26

- Ability to define a list of pages to whitelist and by what request method.

## 1.0.0 - 2020-02-19

- Initial release

[Unreleased]: https://github.com/rappasoft/laravel-boilerplate/compare/v1.0.1...develop
[1.0.1]: https://github.com/rappasoft/laravel-boilerplate/compare/v1.0.0...v1.0.1
