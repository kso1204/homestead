# PSR 18 Guzzle Adapter

This package provides a simple PSR-18 adapter for the Guzzle HTTP client.
