<?php
namespace ParagonIE\Certainty\Exception;

/**
 * Class NetworkException
 * @package ParagonIE\Certainty\Exception
 */
class NetworkException extends CertaintyException
{

}
