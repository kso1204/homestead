<?php
namespace ParagonIE\Certainty\Exception;

/**
 * Class BundleException
 * @package ParagonIE\Certainty\Exception
 */
class BundleException extends CertaintyException
{

}
