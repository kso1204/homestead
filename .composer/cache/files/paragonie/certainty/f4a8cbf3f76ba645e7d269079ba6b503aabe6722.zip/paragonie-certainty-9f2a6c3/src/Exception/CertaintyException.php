<?php
namespace ParagonIE\Certainty\Exception;

/**
 * Class CertaintyException
 * @package ParagonIE\Certainty\Exception
 */
class CertaintyException extends \Exception
{

}
