<?php
namespace ParagonIE\Certainty\Exception;

/**
 * Class RemoteException
 * @package ParagonIE\Certainty\Exception
 */
class RemoteException extends NetworkException
{

}
