<?php
namespace ParagonIE\Certainty\Exception;

/**
 * Class CryptoException
 * @package ParagonIE\Certainty\Exception
 */
class CryptoException extends CertaintyException
{

}
