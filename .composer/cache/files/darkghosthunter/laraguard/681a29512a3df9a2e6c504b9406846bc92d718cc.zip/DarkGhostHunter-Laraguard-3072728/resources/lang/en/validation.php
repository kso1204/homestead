<?php

return [
    'totp_code' => 'The Code is invalid or has expired.',
];