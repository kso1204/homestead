@extends($layout)

@section($section)
    @livewire($component, $componentParameters)
@endsection
