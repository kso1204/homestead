---
name: Bug report
about: Report something that's broken
---

### Description

### Steps to reproduce

**Context**
- Livewire version: [e.g. 1.0.0]
- Laravel version: [e.g. 7.0.0]
- Browser: [e.g. Chrome, Safari]
