<?php

require_once 'PrinterInit.php';

$init = new PrinterInit();
$init->init('always');
