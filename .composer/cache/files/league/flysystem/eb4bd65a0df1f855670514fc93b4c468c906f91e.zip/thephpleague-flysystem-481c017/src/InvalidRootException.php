<?php

namespace League\Flysystem;

use RuntimeException;

class InvalidRootException extends RuntimeException implements FilesystemException
{
}
