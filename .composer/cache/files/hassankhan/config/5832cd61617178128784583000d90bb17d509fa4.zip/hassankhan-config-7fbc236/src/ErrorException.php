<?php

namespace Noodlehaus;

class ErrorException extends \ErrorException
{
}
