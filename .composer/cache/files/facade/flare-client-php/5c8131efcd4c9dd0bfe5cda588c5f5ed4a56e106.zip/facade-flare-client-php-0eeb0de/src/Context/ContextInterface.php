<?php

namespace Facade\FlareClient\Context;

interface ContextInterface
{
    public function toArray(): array;
}
